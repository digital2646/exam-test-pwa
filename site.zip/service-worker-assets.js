self.assetsManifest = {
  "version": "BMlYwOqo",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-MXa79h63YqSgdmbvS0bNkKA3KDwy1m0Ltn39cf8aVS4=",
      "url": "404.html"
    },
    {
      "hash": "sha256-t1dVtCGbvTLuao1jx61mevrF5m6mrRvt8vDgXSSVzJk=",
      "url": "ExamSolutionPWA.styles.css"
    },
    {
      "hash": "sha256-T8zsdbInmN+qFCpPojr90dTW0TbjlyKmzNa5azMhuFc=",
      "url": "_framework/ExamSolutionPWA.d18gb3pphs.wasm"
    },
    {
      "hash": "sha256-Icdn/KDBWiYpZS7VwvGT3TWGMuK7vouofRaNtbq+2Vc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ttrl3d180w.wasm"
    },
    {
      "hash": "sha256-4xDpHPPIsYoIYx1TmkXCkigmPOD9PkZ67h1acQkdN+w=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.vtfv3zm02l.wasm"
    },
    {
      "hash": "sha256-4fKg3VR1aTjs33xqBRJT2VyUgSdzFMUeW9CpBlDl0LA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.jzisqd1kuz.wasm"
    },
    {
      "hash": "sha256-dlqbQiN39PAL1L2i/jcxot9O+mmneXUrGC47DX7dUrs=",
      "url": "_framework/Microsoft.AspNetCore.Components.mczij1o7r5.wasm"
    },
    {
      "hash": "sha256-VUuSO6kZbwLvuAxs7/7syx6wccvlGqRn590gtO67YiE=",
      "url": "_framework/Microsoft.Data.Sqlite.nxj70xbyjn.wasm"
    },
    {
      "hash": "sha256-5e2XiyFDTpKcKgecAPJm754Ik56bcXO8HOZzdHPiRIQ=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Abstractions.7xbjzrspsh.wasm"
    },
    {
      "hash": "sha256-qZe8u5PNUmjxKXY9otyha3F/inqQ7rqVLJKGMsqfmK8=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Relational.fu9qwly44s.wasm"
    },
    {
      "hash": "sha256-xZsw/pw7ZqBy8z6HrvrZXgaBFaC+gJcAA9q7Y/3eGX0=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Sqlite.xd9t70m8vn.wasm"
    },
    {
      "hash": "sha256-5ql6J4QbDbjAwg00jNhUt7CG08USXX7ACygPCZyUiJQ=",
      "url": "_framework/Microsoft.EntityFrameworkCore.iepitmnl1k.wasm"
    },
    {
      "hash": "sha256-GMrpMQ5ikmuz/3/nyvSmwGzJD8eVlPXOLNsEc2WUGjQ=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.wa6gupxf5x.wasm"
    },
    {
      "hash": "sha256-VVJIr39ZPu1ogM8j3hG5fxxvbDC41FXCVxnYuEeb/iM=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.1dg6erqk59.wasm"
    },
    {
      "hash": "sha256-b/8G67eMn6Qg3sidy6kx4684cUNT8JUhzRQabyTwZ/0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.jna25i3qey.wasm"
    },
    {
      "hash": "sha256-hR3hJyllFhcAJODYJ4O/15D7zPKt4rm31ndgrYDdAXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dmmcgk01r0.wasm"
    },
    {
      "hash": "sha256-WQS9MCWDe05+uw6QvIaKX92PAx5CqKgAdj4/soWzXQo=",
      "url": "_framework/Microsoft.Extensions.Configuration.xmaagcfcjv.wasm"
    },
    {
      "hash": "sha256-RqKjwS4A60TFyr8S7wSVlzpxNjNvBwEe+VK/deZVayc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.aodudwx8up.wasm"
    },
    {
      "hash": "sha256-o0mKJPHnZfAfoLGjsaTbC5B8uIIyy1BaIBQLj0JuN8g=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.fdol7p708z.wasm"
    },
    {
      "hash": "sha256-5ihSSyMPXx4LoRJhSUZcn/hi1U0VAVY+Yhv0jGD9sf8=",
      "url": "_framework/Microsoft.Extensions.DependencyModel.ajft9b4d0v.wasm"
    },
    {
      "hash": "sha256-crMly92uy9qTGOzRPigTas9a5s4qo6NzGD9ngxg0aSQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.27p4cmtmvb.wasm"
    },
    {
      "hash": "sha256-o3xWqacMFEucT5KIEWKzgbq1Lop/kzbmETPQWdyDJyo=",
      "url": "_framework/Microsoft.Extensions.Logging.pt3o26k47a.wasm"
    },
    {
      "hash": "sha256-TqcuRfsHDo1I9fA6NleVgI/6BwkPHpdQbhJJ7PXpJ7Q=",
      "url": "_framework/Microsoft.Extensions.Options.espvvlqak1.wasm"
    },
    {
      "hash": "sha256-QaKM8S9ICyRl8SGt6Cc3M1DdNerAGBVUTo3pSYL5Ctk=",
      "url": "_framework/Microsoft.Extensions.Primitives.5jtv79dwfq.wasm"
    },
    {
      "hash": "sha256-aUqItU9TychE/hjlgJr2DlYztEYPeTV5rTimfsh0FoE=",
      "url": "_framework/Microsoft.Extensions.Validation.t7hdqum7ip.wasm"
    },
    {
      "hash": "sha256-kA4OIaWbB6obNbKQ/H9VxCYrWP9jiy3WDB3jS21K2o8=",
      "url": "_framework/Microsoft.JSInterop.0s2ioyhd7k.wasm"
    },
    {
      "hash": "sha256-A1+r9KkQJ1Kkm98VWekGd8z84GzOPdY9wh/SHfyyQg4=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ql0ra5mpq.wasm"
    },
    {
      "hash": "sha256-61J9AZuB96QzNI/TNSHKwepdqv9/lkCrXGhgldqYFgw=",
      "url": "_framework/SQLite-net.jm0j5l34q4.wasm"
    },
    {
      "hash": "sha256-1M0mCan4rJV+gMqfJphCDvDGZnfx/rEMsRWeVhmq1Tw=",
      "url": "_framework/SQLitePCLRaw.batteries_v2.wxtt5vpcoz.wasm"
    },
    {
      "hash": "sha256-dUZyQk2EOCNuE5QNwaQ3Rm8rC1TwK0VZCtovxyhK3kQ=",
      "url": "_framework/SQLitePCLRaw.core.l883yav5k0.wasm"
    },
    {
      "hash": "sha256-1B3bi0A2sLHJU8DZ5TiCULvaAOEYNJCnU1TS5b5p3As=",
      "url": "_framework/SQLitePCLRaw.provider.e_sqlite3.81s5l0tnag.wasm"
    },
    {
      "hash": "sha256-dygl3J1gyEquajR1cjAa6vuq2eMypfBYTUZLSuCf8+E=",
      "url": "_framework/System.Collections.Concurrent.94rhkklqe3.wasm"
    },
    {
      "hash": "sha256-aVUoi1B3fjshHQCgBwfssMXg8nUWnFv2EvBG0X0mTZQ=",
      "url": "_framework/System.Collections.Immutable.9cb8aocwee.wasm"
    },
    {
      "hash": "sha256-2EhCd+D1pJ37hHsFN9n4b8W55zroNInOvdhmPLixzfo=",
      "url": "_framework/System.Collections.NonGeneric.ktknq95i70.wasm"
    },
    {
      "hash": "sha256-m2ChQCCgmNqpvn01j7TkEcFzZKkOKJdKtXyLo+uaOzI=",
      "url": "_framework/System.Collections.Specialized.9z78h5e8ro.wasm"
    },
    {
      "hash": "sha256-sDPZkpI/yVNEXQNck9c8U50y1ESVrRvy8CfRB5NnJp8=",
      "url": "_framework/System.Collections.kzvznc45vs.wasm"
    },
    {
      "hash": "sha256-02JznGjngN5UVKYZInkQQzLqLRCgPnlXHgpzh1kHAWY=",
      "url": "_framework/System.ComponentModel.Annotations.z8hifnx4fy.wasm"
    },
    {
      "hash": "sha256-WxmtQBjnqyWU9/WQOcBrdpX0BlhxVqiNFi00xfQ5Tx8=",
      "url": "_framework/System.ComponentModel.Primitives.l05d81y3vm.wasm"
    },
    {
      "hash": "sha256-F3bZHLvTRVHBcrLlCyECGulocPPb7c0s1c+SihUm7rY=",
      "url": "_framework/System.ComponentModel.TypeConverter.trwc9g7s4s.wasm"
    },
    {
      "hash": "sha256-wVelT5q2Ayvz9D1JWzDUNVki/rxamE8kOKs/ckVx+70=",
      "url": "_framework/System.ComponentModel.vcj9uwgm8b.wasm"
    },
    {
      "hash": "sha256-+NnQFafrUZWEa7OIZwG9tiqhkAh/lbGpw3Jb7cG0nGo=",
      "url": "_framework/System.Console.s30y5jaktf.wasm"
    },
    {
      "hash": "sha256-LcOC66an8ZMV+j/etec4hgogVuKZIsYarnZBTbkbaFQ=",
      "url": "_framework/System.Data.Common.992bn38k0y.wasm"
    },
    {
      "hash": "sha256-Ti2iEd5R1vC9JIasq5Hf2r7L7U7XjZTJlzHXkZz2P4A=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.m7mx0dhu0k.wasm"
    },
    {
      "hash": "sha256-dVt0XwPc6f7tk5iswSyUD8zg4XM89bflO1lrCzqQlZs=",
      "url": "_framework/System.Diagnostics.TraceSource.3e9c22qvdf.wasm"
    },
    {
      "hash": "sha256-U7vDYewKVIjYYSCnJnMPTeEU3vYWRXRe1/ES8sUC5gY=",
      "url": "_framework/System.Diagnostics.Tracing.hv40kq725r.wasm"
    },
    {
      "hash": "sha256-v8hZQJX5viuuPlRuIGevgWRJmnofhoKuhsnBWOQUomE=",
      "url": "_framework/System.Drawing.Primitives.t57wj6kp7s.wasm"
    },
    {
      "hash": "sha256-v8fB+rYlrZlKumwHku/jCAAn4sl4ga5n9OfjpWDMAxo=",
      "url": "_framework/System.Drawing.r5f079tipk.wasm"
    },
    {
      "hash": "sha256-P3efMSOfVCOb4KRJxC8w5mdhwshNltAbNhD4m3E4ekU=",
      "url": "_framework/System.IO.Pipelines.d9jdqrkwk1.wasm"
    },
    {
      "hash": "sha256-ImyJSZ6BcwY+8m+kxxsKJfQSAkalk/zl5bzAnIcTzmU=",
      "url": "_framework/System.Linq.6fcxbdn4ya.wasm"
    },
    {
      "hash": "sha256-elPorgjP55gvgWfTekh1RCbzY4clTgHOtBjc/C6e0Q0=",
      "url": "_framework/System.Linq.Expressions.ev5n21vc0v.wasm"
    },
    {
      "hash": "sha256-kxUE2oePfJzCH3dzAte9jf6aTIoD6ZEjLdFXaeX+SqE=",
      "url": "_framework/System.Linq.Queryable.h7i9yd7cb1.wasm"
    },
    {
      "hash": "sha256-OxVk8eR5hZ3xWmUsshq0nxyg6Jq1my0JxQq0RVpUH6g=",
      "url": "_framework/System.Memory.tuz9d0q4rb.wasm"
    },
    {
      "hash": "sha256-2CO5W6kbJa/g8PpfEIIQ5ahpP9Wtg0O+CPYxefhaBeY=",
      "url": "_framework/System.Net.Http.crhdpiwk6m.wasm"
    },
    {
      "hash": "sha256-7HZbru2aD3rOcSDXHH96P9Z3tfopc/oHHEfukQxFZbw=",
      "url": "_framework/System.Net.NetworkInformation.sq9rrp2o7u.wasm"
    },
    {
      "hash": "sha256-o355CtHGLiE1PQVszXKupVXmL/1gq22hkraaCgWBJBQ=",
      "url": "_framework/System.Net.Primitives.bmcry5b3xm.wasm"
    },
    {
      "hash": "sha256-NdCIzOL5oU4FQKDsf/0nWNAyrjMmkzkKcORmvVNYBOY=",
      "url": "_framework/System.ObjectModel.lsruosqhoo.wasm"
    },
    {
      "hash": "sha256-QewvE98NbC4TcL805IcXmABRwmDHZTzZfLwsNfBkB6I=",
      "url": "_framework/System.Private.CoreLib.tx0e00nqdb.wasm"
    },
    {
      "hash": "sha256-CQmj2EYLbwrpR1wi7L664k04iBORGYVI9dBHLIzOqUA=",
      "url": "_framework/System.Private.Uri.f2a04wcgtb.wasm"
    },
    {
      "hash": "sha256-i198MQZR+1UweubZMaPxshnjaMdKg7GpABa1PyrQ/wo=",
      "url": "_framework/System.Private.Xml.bgsmuain2a.wasm"
    },
    {
      "hash": "sha256-hj26LVfbFpoVPyXTjAXdVk41FKNiFwr2eGNynxIaSNQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.qba5uzr262.wasm"
    },
    {
      "hash": "sha256-aItwcGJG0nUkJHoI+lQxAtd/5WlYSK+ps+17g/JlTe8=",
      "url": "_framework/System.Runtime.InteropServices.kdkh69wi84.wasm"
    },
    {
      "hash": "sha256-Z1pCPuQU3Dz7ICeg5E8+sshxYOjg3Rf8wg0A6YCfxD8=",
      "url": "_framework/System.Runtime.Numerics.tr753fjhph.wasm"
    },
    {
      "hash": "sha256-PIuM1j2Ttm83BvLLtpoDH4oxFDAGua6/qRW/czVyrxI=",
      "url": "_framework/System.Runtime.Serialization.Formatters.8taiof1ny4.wasm"
    },
    {
      "hash": "sha256-hxuNmbus2Z+63XM9Eth9ODyEKJMMiyGzEU4DEKpipEw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.1u4wc6yayu.wasm"
    },
    {
      "hash": "sha256-aszyp9WYSy/Ox3HzoRiJuJVu8f0C0hx2nVy/PB77Fig=",
      "url": "_framework/System.Runtime.ee120kne1d.wasm"
    },
    {
      "hash": "sha256-43WmxiTqXiq1SWJU2ygtNonLnroG1dqc4Mk9gtkVW9k=",
      "url": "_framework/System.Security.Cryptography.hja79wv5r5.wasm"
    },
    {
      "hash": "sha256-X8UFA3Hlm9BlJ2BLHrqFPm2x6oR9pfvqYE1+5AFFPU0=",
      "url": "_framework/System.Text.Encodings.Web.zbnd62gslq.wasm"
    },
    {
      "hash": "sha256-BZdJ50rUzEgU/NGNwfnnjR3DkmyjcW2uRFwikDOHTTQ=",
      "url": "_framework/System.Text.Json.1l142lkvtk.wasm"
    },
    {
      "hash": "sha256-eim8ba8R20rBV33DgUcpkP5TBdzvUmKakc1pM+/qUSc=",
      "url": "_framework/System.Text.RegularExpressions.60kluo4829.wasm"
    },
    {
      "hash": "sha256-6v0chrsr81yBj66fCHsQIYXrgBkW8rOJGv5K3Jc5iN8=",
      "url": "_framework/System.Threading.25uemfg8yk.wasm"
    },
    {
      "hash": "sha256-RyU1wgKw+/0HVPjnoMow6WYPZ0FlCtkfXVqtg0G2xEM=",
      "url": "_framework/System.Threading.Thread.fu4jue3e9d.wasm"
    },
    {
      "hash": "sha256-34iNq9s688u0UcFhsPtaaqwrDYw6e6GSsuUR3F7zVi4=",
      "url": "_framework/System.Transactions.Local.5nmm7p76y1.wasm"
    },
    {
      "hash": "sha256-Gs5bAip0Y07Y7rdk4CYnpzrBeGplAudFAELUELfBy80=",
      "url": "_framework/System.a3z5tpzyvn.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-RThJYbbRCQfFgK2IKyj47trsb6HqGql7iFPqXvkvgKg=",
      "url": "_framework/dotnet.native.bs0bv4a1x9.js"
    },
    {
      "hash": "sha256-j+WIzkfKXZHnkua7gpYH4KraW+1xsbDP7kCfLe12IPw=",
      "url": "_framework/dotnet.native.xsqvd91i4s.wasm"
    },
    {
      "hash": "sha256-/3dBg9sj1yLD3h0PDMHnNUXWs/2zWwIMEzom1Xz3Q40=",
      "url": "_framework/dotnet.runtime.5nc8i5dl74.js"
    },
    {
      "hash": "sha256-gpUSfr0AenDSQD7ig3KaBgrHMhAG1z88SpUnHgAY29k=",
      "url": "_framework/dotnet.yr129bcma6.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-GwMvQFeiWFQ/32f2iG1sY6jFT8tuPXOCs+b/HZX7yEc=",
      "url": "_framework/netstandard.7hjepc094w.wasm"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-xTPCAN9LIpL+WSTeyPbKisFknhELnVRpghy/V+iQRkk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-t8dVZ8DoFgvbPy35jvvb/Pn1H7nteF6zjfLBs3cEl7w=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-WcT/PM+gl1wzvfz1I/b4su0p3akgeG2erYBT3A5spB4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-zZwRpwDa73mzv0voI8MgLZk/WijYNJF2alQRhoAEWEI=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-I8i6B6mJujZSNzMRy3iSYjzM19lWzW4Mf97A8VcGueg=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-dqujxK6UfpxqMowtaZBO9JOLuPSTBdYtEWDraFPfvvE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-6vlkqIf+0a8hOGDvyatg87n62Ki0Kfu+k7a5FhJfdHU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Z1Z+OkzQWQyA8Qa7/s9vG5mzUb7sm295OJLNHEMhrpA=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-CiWiragqqlZnGr5cW9nJEr6NS4VVYgBe83LC28ya22E=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-kdDtxYzWsw45BGF0e12SxfwhDdjGqT5p9A/ALs/EV0g=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-1yxyQ0Jqx8IMPzCohbVEmoGpEaj7IEqboTkAiT06nAU=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
